<?php

phpinfo()

?>