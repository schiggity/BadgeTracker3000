edges = [];
adjacent = [[]];
v = [];

distance = [999];
prev = [[]];

def graphin():
	global edges;
	global verticies;
	file = open("graphIN2.txt");
	x=1;
	
	#print("yes");
	
	for line in file:
		#verticies +=1;
		adjacent.append([]);
		ej = [];
		noColon = line.replace(":", "");
		noEnter = noColon.rstrip();	
		input = noEnter.split(' ');
		
		input = input[1:];
		
		k=1;
		while k < len(input): 
			if [int(float(input[k])), int(float(input[k-1])), x] not in edges:
				ej = [int(float(input[k])),x,int(float(input[k-1]))];
				#print("\n", ej);
				edges.append(ej);
			adjacent[x].append([int(float(input[k])), int(float(input[k-1]))]);
			k+=2;
		#vertex.append([999,x]);
		distance.append(999);
		prev.append('U');
		v.append(x);
		x+=1;
		
	#edges = sorted(edges, key=itemgetter(0));
	file.close();
	
def siftDown(list, start, end):
	s = start;
	#print("#################start#################\n");
	while s * 2 + 1 <= end:
		child = s * 2 + 1;
		temp = s;
		#print("temp:", list[temp]);
		#print("child: ",list[child]);
		#print("NextChild: ",list[child+1]);
		
		if int(float(list[temp][0])) > int(float(list[child][0])):
			#print("\n",list[temp][0]);
			temp = child;
		if (child + 1 <= end) and (int(float(list[temp][0])) > int(float(list[child + 1][0]))):
			#print("\n",list[temp][0]);
			#print("\n",list[child][0]);
			#print("\n",list[child+1][0]);
			temp = child + 1;
		if temp == s:
			return
		else:
			list[s], list[temp] = list[temp], list[s];
			
			#print("list[s]:", list[s], s);
			#print("list[temp]: ",list[temp], temp);
			s = temp;

def heapify(list):
	## start at last parent
	start = ((len(list)-2)//2);
	
	while start >= 0:
		siftDown(list, start, len(list)-1);
		start -= 1;

def update(x):
	indexOf =0;
	for a in adjacent[x]:
		for v in vertex:
			if int(float(v[1])) == int(float(a[1])):
				indexOf = vertex.index(v);
				vertex[indexOf][0] += a[0];

def Djikstra(source):
	distance[source] = 999;
	prev[source] = 'U';
	
	u = source;
	v.pop(u);
	while v:
		
		print(adjacent[u]);
		for ver in adjacent[u]:
			alt = distance[u] - ver[0];
			if alt < distance[u] and ver in v:
				distance[ver[1]] = alt;
				prev[ver[1]] = u;
		
		#heapy heapy heap
		#sleepy sleepy sleep
		u = distance.index(min(distance));
		print(u);
		v.pop(u-1);
				
				
				
graphin();
#heapify(vertex);
Djikstra(1);
print(prev);














