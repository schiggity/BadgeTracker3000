edges = [];
parent = [0];
rank = [0];
verticies = 0;

from operator import itemgetter;

def makeSet(x):
	parent[int(float(x))] = int(float(x));
	rank[x] = 0;
	
def findSet(x):
	if parent[x] != x:
		parent[x] = findSet(parent[x]);
	return parent[x];
	
def unionSet(x,y):
	rootX = findSet(x);
	rootY = findSet(y);
	if rootX == rootY:
		return;
	
	if rank[rootX] < rank[rootY]:
		parent[rootX] = rootY;
	elif (rank[rootX] > rank[rootY]):
		parent[rootY] = rootX;
	else:
		parent[rootY] = rootX;
		rank[rootX] = rank[rootX] + 1
	
def graphin():
	global edges;
	global verticies;
	file = open("graphIN2.txt");
	x=1;
	
	#print("yes");
		
	for line in file:
		verticies +=1;
		ej = [];
		parent.append(0);
		rank.append('');
		noColon = line.replace(":", "");
		noEnter = noColon.rstrip();	
		input = noEnter.split(' ');
		
		input = input[1:];
		
		k=1;
		while k < len(input): 
			if [input[k], input[k-1], str(x)] not in edges:
				ej = [input[k],str(x),input[k-1]];
				edges.append(ej);
			k+=2;
		x+=1;
	edges = sorted(edges, key=itemgetter(0));
	file.close();

def kruskal(graph):
	G = [];
	print(verticies);
	for x in range(1,verticies+1):
		print(x);
		makeSet(x);
	for edge in graph:
		if findSet(int(float(edge[1]))) != findSet(int(float(edge[2]))):
			G.append([edge[1], edge[2]]);
			unionSet(int(float(edge[1])), int(float(edge[2])));
	return G;
		
	
	
graphin();
print(parent);
for x in edges:
	print(x);
	
mst = kruskal(edges);

print(mst);

fileOut = open('kruskalout.txt', 'w');

for i in mst:
	fileOut.writelines(i);
	fileOut.write("\n");






