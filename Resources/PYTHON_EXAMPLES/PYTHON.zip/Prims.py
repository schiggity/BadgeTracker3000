
edges = [];
vertex = [];
adjacent = [[]];
v = [];
final = [];
prev = [];
next = [];

from operator import itemgetter;

def graphin():
	global edges;
	global verticies;
	file = open("graphIN2.txt");
	x=1;
	
	#print("yes");
	
	for line in file:
		#verticies +=1;
		adjacent.append([]);
		ej = [];
		noColon = line.replace(":", "");
		noEnter = noColon.rstrip();	
		input = noEnter.split(' ');
		
		input = input[1:];
		
		k=1;
		while k < len(input): 
			if [input[k], input[k-1], str(x)] not in edges:
				ej = [input[k],str(x),input[k-1]];
				#print("\n", ej);
				edges.append(ej);
			adjacent[x].append([input[k],input[k-1]]);
			k+=2;
		vertex.append([999,x]);
		v.append(x);
		x+=1;
		
	#edges = sorted(edges, key=itemgetter(0));
	file.close();
	
def siftDown(list, start, end):
	s = start;
	#print("#################start#################\n");
	while s * 2 + 1 <= end:
		child = s * 2 + 1;
		temp = s;
		#print("temp:", list[temp]);
		#print("child: ",list[child]);
		#print("NextChild: ",list[child+1]);
		
		if int(float(list[temp][0])) > int(float(list[child][0])):
			#print("\n",list[temp][0]);
			temp = child;
		if (child + 1 <= end) and (int(float(list[temp][0])) > int(float(list[child + 1][0]))):
			#print("\n",list[temp][0]);
			#print("\n",list[child][0]);
			#print("\n",list[child+1][0]);
			temp = child + 1;
		if temp == s:
			return
		else:
			list[s], list[temp] = list[temp], list[s];
			
			#print("list[s]:", list[s], s);
			#print("list[temp]: ",list[temp], temp);
			s = temp;

def heapify(list):
	## start at last parent
	start = ((len(list)-2)//2);
	
	while start >= 0:
		siftDown(list, start, len(list)-1);
		start -= 1;

def update(x):
	indexOf =0;
	for a in adjacent[x]:
		for v in vertex:
			#print(v);
			#print(a);
			if int(float(v[1])) == int(float(a[1])):
				indexOf = vertex.index(v);
				#print(indexOf);
				if (int(float(a[0])) < int(float(vertex[indexOf][0]))):
					vertex[indexOf][0] = a[0];
graphin();
"""
last = len(vertex)-1;

#set vertex 1 distance to 0;
vertex[0][0] = 0;
#update vertex 1
update(1);
#extract 1
vertex[0], vertex[last] = vertex[last], vertex[0];
last-=1;
#make vertex a heap
siftDown(vertex, 0, last);
"""
vertex[0][0] = 0;
heapify(vertex);
x = vertex[0]
last = len(vertex)-1;

while v:
	#extract x
	prev.append(x[1]);
	x = vertex[0];
	print("extract: ", x[1]);
	update(int(float(x[1])));
	#make vertex a heap
	next.append(x[1]);
	vertex[0], vertex[last] = vertex[last], vertex[0];
	last -= 1;	
	siftDown(vertex, 0, last);
	#for line in vertex:
		#print(line);
	if (x[1] in v):
		v.remove(x[1]);
	
	

file = open('primOut.txt', 'w');

prev = prev[1:];
next = next[1:];

print(prev);
print(next);

for line in edges:
	print(line);

adjacent
	
for x in range(len(prev)):
	if any(next[x] == int(float(a[1])) for a in adjacent[int(float(prev[x]))]):
		file.write("[" + str(prev[x]) + "," + str(next[x]) + "]");
	else:
		for i in reversed(prev):
			if any(next[x] == int(float(a[1])) for a in adjacent[int(float(i))]):
				file.write("[" + str(i) + "," + str(next[x]) + "]");


				

#print(edges);
#print(vertex);		
			


			
			
			
			
			
			
			
			
			
			
			
			
			
			
			