import time;
		
#######Insertion Sort#######
def insertionSorter():

	a = [];

	t = time.process_time();
	for line in f:
		a.append(line);
	for i in range(len(a)):
		x = a[i];
		j = i;
		
		while (j > 0) and (a[j-1] > x):
			a[j] = a[j-1];
			j = j-1;
		a[j] = x;
	for item in a:
		output.write(item);
	timeTaken = time.process_time() - t;

	print('sort time:',timeTaken);

	
	
#######Merge Sort#######

def merge(l, left, right):

		i=0;
		j=0;
		k=0;
		
		while i<len(left) and j<len(right):
			if left[i] < right[j]:
				l[k] = left[i];
				i=i+1;
			else:
				l[k] = right[j];
				j = j+1;
			k = k+1;
			
		while i< len(left):
			l[k] = left[i];
			i=i+1;
			k=k+1
		while j<len(right):
			l[k] = right[j];
			j=j+1;
			k=k+1;

def mergeSort(l):
	if len(l)>1:
		mid = len(l)//2
		left = l[:mid]
		right = l[mid:]
		
		mergeSort(left);
		mergeSort(right);
		merge(l, left, right);

def mergeSorter():		
	a = [];
	t = time.process_time();

	for line in f:
		a.append(line);
	mergeSort(a);

	for item in a:
		output.write(item);
	timeTaken = time.process_time() - t;

	print('sort time:',timeTaken);



#######Heap sort#######

def siftDown(list, start, end):
	s = start;
	
	while s * 2 + 1 <= end:
		child = s * 2 + 1;
		temp = s;
		#print("temp:", list[temp]);
		#print("child: ",list[child]);
			
		
		if list[temp] < list[child]:
			temp = child;
		if (child + 1 <= end) and (list[temp] < list[child + 1]):
			temp = child + 1;
		if temp == s:
			return
		else:
			list[s], list[temp] = list[temp], list[s];
			s = temp;

def heapify(list):
	## start at last parent
	start = ((len(list)-2)//2);
	
	while start >= 0:
		siftDown(list, start, len(list)-1);
		start -= 1;

def heapSorter():

	heap = [];

	t = time.process_time();

	for line in f:
		#heapq.heappush(heap,line);
		heap.append(line);

	heapify(heap);
		
	buildTime = time.process_time() - t;
	#for i in range(len(heap)):
		#output.write(heapq.heappop(heap));
	last = len(heap)-1;

	while last > 0:
		#print("sorting");
		heap[0], heap[last] = heap[last], heap[0];
		last -= 1;
		siftDown(heap, 0, last);

	for i in heap:
		output.write(i);
		#print(i);
		
	timeTaken = time.process_time() - t;

	print('build time:', buildTime);
	print('sort time:', timeTaken);

	
	
choice = '';
file = input("which file size would you like to test?(15,30,45,...,150):");
type = input("permuted or sorted?(P/S):");
if type == 'P' or type == 'p':
	string = 'permuted\perm' + file + 'k.txt';
else:
	string = 'sorted\sorted' + file + 'k.txt';

f = open(string, 'r');

choice = input("which sort would you like to use?(H/M/I) or x to exit:");
if choice == 'H' or choice == 'h':
	output = open(('HS' + file + 'K.txt'), 'w');
	heapSorter();
if choice == 'M' or choice == 'm':
	output = open(('MS' + file + 'K.txt'), 'w');
	mergeSorter();
if choice == 'I' or choice == 'i':
	output = open(('IS' + file + 'K.txt'), 'w');
	insertionSorter();
		

	

f.close();
output.close();
input("Press enter to continue");
