Run like a normal python 3.5 program
in command line type 

python graph.py 

this is assuming you have set up the PATH variable in windows which i guess you have
if not here

http://showmedo.com/videotutorials/video?name=960000&fromSeriesID=96